<?php
/**
 * Portada: vídeo a pantalla completa + hero de bienvenida.
 * front-page.php se usa automáticamente como portada del sitio.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>

<section id="video-hero" aria-label="Concertsost — vídeo de presentación">
  <video autoplay muted loop playsinline poster="<?php echo esc_url( get_template_directory_uri() . '/assets/video/hero-poster.jpg' ); ?>" preload="auto">
    <source src="<?php echo esc_url( get_template_directory_uri() . '/assets/video/hero-video.mp4' ); ?>" type="video/mp4">
  </video>
  <div class="video-overlay" aria-hidden="true"></div>
  <div class="video-hero-inner">
    <p class="eyebrow reveal">Concertsost · Ecosistema de eventos</p>
    <h1 class="reveal d1">El punto de encuentro que mueve el ecosistema de eventos.</h1>
  </div>
  <a href="#hero" class="scroll-cue" aria-label="Bajar a la siguiente sección">
    <span>Descubre más</span>
    <span class="chevron" aria-hidden="true"></span>
  </a>
</section>

<section id="hero" class="hero">
  <div class="blob blob-hero-1" aria-hidden="true"></div>
  <div class="blob blob-hero-2" aria-hidden="true"></div>
  <div class="wrap hero-grid">
    <div>
      <p class="eyebrow reveal">Concertsost · Ecosistema de eventos</p>
      <h1 class="reveal">De la idea a la alianza: bienvenido al ecosistema Concertsost.</h1>
      <p class="lede reveal d1">Conectamos empresas, marcas, instituciones y profesionales para generar alianzas, patrocinios y nuevos proyectos alrededor de los eventos.</p>
      <div class="hero-ctas reveal d2">
        <a class="btn btn-primary" href="<?php echo esc_url( concertsost_page_link( 'contacto' ) ); ?>">Hablemos</a>
        <a class="btn btn-secondary" href="<?php echo esc_url( concertsost_page_link( 'que-hacemos' ) ); ?>">Qué hacemos</a>
      </div>
      <div class="chip-row reveal d3">
        <span class="chip">Alianzas</span>
        <span class="chip">Patrocinios</span>
        <span class="chip">Turismo + música</span>
        <span class="chip">Innovación</span>
        <span class="chip">Sostenibilidad</span>
        <span class="chip">Networking</span>
        <span class="chip">Nuevos formatos</span>
      </div>
    </div>
    <div class="hero-canvas-wrap reveal d2" aria-hidden="true">
      <div class="hero-canvas-glow"></div>
      <canvas id="nodeCanvas"></canvas>
    </div>
  </div>
</section>

<?php get_footer(); ?>
