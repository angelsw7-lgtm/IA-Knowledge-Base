<?php
/**
 * Portada única: réplica fiel, en una sola página de scroll continuo,
 * del artefacto original — vídeo de portada, hero, y las secciones
 * Qué es, Qué hacemos, Proyectos, Ecosistema y Contacto en secuencia.
 * front-page.php se usa automáticamente como portada del sitio.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>

  <section id="video-hero" aria-label="Concertsost — vídeo de presentación">
    <video autoplay muted loop playsinline poster="<?php echo esc_url( get_template_directory_uri() . '/assets/video/hero-poster.jpg' ); ?>" preload="auto">
      <source src="<?php echo esc_url( get_template_directory_uri() . '/assets/video/hero-video.mp4' ); ?>" type="video/mp4">
    </video>
    <div class="video-overlay" aria-hidden="true"></div>
    <div class="video-hero-inner">
      <p class="eyebrow reveal">Concertsost · Ecosistema de eventos</p>
      <h1 class="reveal d1">El punto de encuentro que mueve el ecosistema de eventos.</h1>
    </div>
    <a href="#hero" class="scroll-cue" aria-label="Bajar a la siguiente sección">
      <span>Descubre más</span>
      <span class="chevron" aria-hidden="true"></span>
    </a>
  </section>

  <section id="hero" class="hero">
    <div class="blob blob-hero-1" aria-hidden="true"></div>
    <div class="blob blob-hero-2" aria-hidden="true"></div>
    <div class="wrap hero-grid">
      <div>
        <p class="eyebrow reveal">Concertsost · Ecosistema de eventos</p>
        <h1 class="reveal">De la idea a la alianza: bienvenido al ecosistema Concertsost.</h1>
        <p class="lede reveal d1">Conectamos empresas, marcas, instituciones y profesionales para generar alianzas, patrocinios y nuevos proyectos alrededor de los eventos.</p>
        <div class="hero-ctas reveal d2">
          <a class="btn btn-primary" href="#contacto">Hablemos</a>
          <a class="btn btn-secondary" href="#que-hacemos">Qué hacemos</a>
        </div>
        <div class="chip-row reveal d3">
          <span class="chip">Alianzas</span>
          <span class="chip">Patrocinios</span>
          <span class="chip">Turismo + música</span>
          <span class="chip">Innovación</span>
          <span class="chip">Sostenibilidad</span>
          <span class="chip">Networking</span>
          <span class="chip">Nuevos formatos</span>
        </div>
      </div>
      <div class="hero-canvas-wrap reveal d2" aria-hidden="true">
        <div class="hero-canvas-glow"></div>
        <canvas id="nodeCanvas"></canvas>
      </div>
    </div>
  </section>

  <section id="que-es">
    <div class="seam seam-to-que-es"></div>
    <div class="wrap que-es-grid">
      <div class="reveal">
        <p class="eyebrow">01 · Qué es Concertsost</p>
        <p><strong>Concertsost es una marca B2B del ecosistema de eventos.</strong> No somos una productora musical, ni una consultora tradicional, ni una plataforma de ticketing — somos el punto donde empresas, marcas, instituciones y profesionales se conectan para construir algo nuevo alrededor de los eventos.</p>
        <p>Trabajamos en el cruce entre negocio, cultura y oportunidad: alianzas, patrocinios, turismo y música, innovación y sostenibilidad aplicada al mundo de los encuentros profesionales.</p>
      </div>
      <div class="reveal d1">
        <div class="photo-frame tilt" data-tilt>
          <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/que-es-referencia.jpg' ); ?>" alt="Concierto de Hombres G — producción Concertsost" loading="lazy">
        </div>
      </div>
    </div>
  </section>

  <section id="que-hacemos">
    <div class="seam seam-to-hacemos"></div>
    <div class="wrap">
      <div class="section-head reveal">
        <p class="eyebrow">02 · Qué hacemos</p>
        <h2>Nueve territorios, un mismo punto de conexión</h2>
        <p>Las áreas en las que Concertsost genera oportunidades dentro del ecosistema de eventos.</p>
      </div>
      <div class="areas-grid">
        <div class="area-card reveal tilt" data-tilt><span class="node-dot"></span><h3>Alianzas</h3><p>Conectamos empresas e instituciones para construir colaboraciones con propósito.</p></div>
        <div class="area-card reveal d1 tilt" data-tilt><span class="node-dot"></span><h3>Nuevos proyectos</h3><p>Impulsamos iniciativas que nacen del cruce entre distintos sectores del ecosistema.</p></div>
        <div class="area-card reveal d2 tilt" data-tilt><span class="node-dot"></span><h3>Patrocinios</h3><p>Acercamos marcas y eventos que comparten valores y objetivos.</p></div>
        <div class="area-card reveal d3 tilt" data-tilt><span class="node-dot"></span><h3>Turismo + música</h3><p>Unimos el atractivo cultural de la música con el desarrollo del turismo profesional.</p></div>
        <div class="area-card reveal tilt" data-tilt><span class="node-dot"></span><h3>Innovación</h3><p>Exploramos nuevos formatos y tecnologías aplicadas a la experiencia de eventos.</p></div>
        <div class="area-card reveal d1 tilt" data-tilt><span class="node-dot"></span><h3>Sostenibilidad</h3><p>Integramos criterios sostenibles en cada alianza y proyecto.</p></div>
        <div class="area-card reveal d2 tilt" data-tilt><span class="node-dot"></span><h3>Networking</h3><p>Creamos espacios de encuentro entre profesionales del sector.</p></div>
        <div class="area-card reveal d3 tilt" data-tilt><span class="node-dot"></span><h3>Nuevos formatos</h3><p>Diseñamos maneras distintas de vivir y organizar encuentros profesionales.</p></div>
      </div>
    </div>
  </section>

  <section id="proyectos">
    <div class="seam seam-to-proyectos"></div>
    <div class="wrap">
      <div class="section-head on-dark reveal">
        <p class="eyebrow on-dark">03 · Proyectos y oportunidades</p>
        <h2 style="color:#fff;">Proyectos del ecosistema</h2>
        <p>Una muestra de alianzas y producciones en las que Concertsost ha estado detrás del escenario.</p>
      </div>
      <div class="proj-grid">
        <div class="proj-card reveal">
          <div class="proj-img" style="background-image:url('<?php echo esc_url( get_template_directory_uri() . '/assets/img/proyecto-skyfest-benidorm.jpg' ); ?>')" role="img" aria-label="SkyFest Benidorm"></div>
          <div class="proj-body">
            <span class="proj-tag">Proyecto realizado</span>
            <h3>SkyFest Benidorm</h3>
            <p>Gestión y asesoramiento del festival.</p>
          </div>
        </div>
        <div class="proj-card reveal d1">
          <div class="proj-img" style="background-image:url('<?php echo esc_url( get_template_directory_uri() . '/assets/img/proyecto-hombresg-castellon.jpg' ); ?>')" role="img" aria-label="Hombres G en Castellón"></div>
          <div class="proj-body">
            <span class="proj-tag">Proyecto realizado</span>
            <h3>Hombres G en Castellón</h3>
            <p>Producción y gestión íntegra del concierto.</p>
          </div>
        </div>
        <div class="proj-card reveal d2">
          <div class="proj-img" style="background-image:url('<?php echo esc_url( get_template_directory_uri() . '/assets/img/proyecto-vinalfest.jpg' ); ?>')" role="img" aria-label="Vinal Fest"></div>
          <div class="proj-body">
            <span class="proj-tag">Proyecto realizado</span>
            <h3>Vinal Fest</h3>
            <p>Producción y gestión íntegra del festival.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="ecosistema">
    <div class="wrap">
      <div class="section-head on-dark reveal">
        <p class="eyebrow on-dark">04 · Ecosistema</p>
        <h2 style="color:#fff;">Empresas, instituciones y profesionales</h2>
        <p>Marcas, instituciones y partners que forman parte del ecosistema Concertsost.</p>
      </div>
      <div class="partner-row reveal">
        <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-ayto-castello.png' ); ?>" alt="Ayuntamiento de Castellón" loading="lazy"></div>
        <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-babalu.png' ); ?>" alt="Babalú" loading="lazy"></div>
        <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-logo2.png' ); ?>" alt="Partner Concertsost" loading="lazy"></div>
        <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-bcdme.png' ); ?>" alt="BCDME" loading="lazy"></div>
        <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-skyfest.png' ); ?>" alt="SkyFest" loading="lazy"></div>
        <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-patos.png' ); ?>" alt="Producciones Artísticas Patos" loading="lazy"></div>
      </div>
    </div>
  </section>

  <section id="contacto">
    <div class="seam seam-to-contacto"></div>
    <div class="blob contact-glow" aria-hidden="true"></div>
    <div class="wrap contact-inner">
      <div class="reveal">
        <p class="eyebrow on-dark">05 · Contacto</p>
        <h2>¿Hablamos de tu próxima alianza?</h2>
        <p class="lede">Empresas, marcas, instituciones y profesionales del ecosistema de eventos — cuéntanos tu proyecto.</p>
      </div>
      <div class="contact-actions reveal d1">
        <a class="btn btn-onDark" href="mailto:info@concertsost.com">info@concertsost.com</a>
        <a class="btn btn-onDark-outline" href="mailto:comunicacion@concertsost.com">comunicacion@concertsost.com</a>
        <span class="contact-note">Información general · Comunicación y prensa</span>
      </div>
    </div>
    <div class="seam-bottom seam-to-footer"></div>
  </section>

<?php get_footer(); ?>
