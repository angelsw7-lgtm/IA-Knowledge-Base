CONCERTSOST — TEMA DE WORDPRESS (una sola página)
====================================================

Instalación
-----------
1. Comprime la carpeta "concertsost" en un archivo .zip (si no te la han
   entregado ya como .zip).
2. En el escritorio de WordPress: Apariencia > Temas > Añadir nuevo >
   Subir tema, selecciona el .zip y actívalo.
3. Listo. No hace falta crear páginas ni tocar Ajustes > Lectura: en
   cuanto activas el tema, la portada del sitio (URL raíz) muestra la
   web completa de una sola vez, igual que el artefacto original.

Qué es este tema
------------------
Es una réplica fiel, en una sola página de scroll continuo, de la web
de Concertsost: vídeo a pantalla completa, hero de bienvenida y las
secciones Qué es, Qué hacemos, Proyectos, Ecosistema y Contacto, todas
seguidas en el mismo documento — no páginas independientes de WordPress.
El menú de cabecera y el pie de página enlazan a anclas dentro de esa
misma página (#que-es, #que-hacemos, #proyectos, #ecosistema,
#contacto), tal y como funciona la web actual.

Qué puedes cambiar desde el escritorio de WordPress
-----------------------------------------------------
- El TEXTO y la estructura de cada sección viven directamente en el
  código de front-page.php, no en el editor de páginas de WordPress —
  así que para cambiar textos, imágenes de proyectos/partners o el
  vídeo de portada, hay que editar ese archivo (o los que están dentro
  de /wp-content/themes/concertsost/assets/), o pedirle a quien
  mantenga la web que lo haga.
- Si creas un menú personalizado en Apariencia > Menús, el tema seguirá
  usando los enlaces de ancla fijos del nav (no lee ese menú); es una
  mejora pendiente si más adelante quieres gestionar el menú desde el
  admin.

Estructura del tema
--------------------
style.css                  Hoja de estilos completa (con la cabecera de
                            tema que exige WordPress) + toda la
                            identidad visual de Concertsost.
functions.php               Registro de scripts y estilos (fuentes,
                            CSS y JS del tema).
header.php                  Cabecera común: doctype, <head>, nav con
                            enlaces de ancla e icono de Instagram.
footer.php                  Pie común: enlaces de ancla, redes y cierre
                            del documento.
front-page.php              La página completa: vídeo-hero + hero +
                            Qué es + Qué hacemos + Proyectos +
                            Ecosistema + Contacto, en el mismo orden
                            que la web en producción. Se usa
                            automáticamente como portada.
page.php / index.php        Plantillas de respaldo genéricas, para
                            casos no cubiertos por front-page.php
                            (por ejemplo, si en el futuro se activa el
                            blog de WordPress).
assets/img/                 Fotografías, logo y logos de partners.
assets/video/                Vídeo de portada (hero-video.mp4) y su
                            imagen de vista previa (hero-poster.jpg).
assets/js/main.js           Menú móvil, animaciones de aparición al
                            hacer scroll, efecto tilt y la animación 3D
                            de nodos del hero.

Contenido pendiente / a revisar
---------------------------------
- El vídeo de portada está comprimido a ~12,7 MB (720p, sin audio) para
  que cargue rápido. Si en algún momento quieres más calidad, sustituye
  assets/video/hero-video.mp4 por una versión nueva con el mismo nombre.
- El logo (assets/img/logo.png) es la versión en color de baja
  resolución ya usada en la web; si se genera un SVG definitivo,
  sustituir este archivo y actualizar las referencias en header.php y
  footer.php si cambia el nombre.
