CONCERTSOST — TEMA DE WORDPRESS
================================

Instalación
-----------
1. Comprime la carpeta "concertsost" en un archivo .zip (si no te la han
   entregado ya como .zip).
2. En el escritorio de WordPress: Apariencia > Temas > Añadir nuevo >
   Subir tema, selecciona el .zip y actívalo.

Qué hace el tema automáticamente al activarlo
----------------------------------------------
- Crea 5 páginas (si no existen ya, buscándolas por su slug) con su
  plantilla ya asignada:
    · Qué es         -> /que-es/
    · Qué hacemos     -> /que-hacemos/
    · Proyectos       -> /proyectos/
    · Ecosistema      -> /ecosistema/
    · Contacto        -> /contacto/
- La portada (vídeo a pantalla completa + hero de bienvenida) se sirve
  sola en la URL raíz del sitio, sin necesidad de tocar Ajustes > Lectura.
- El menú de cabecera y el pie de página enlazan directamente a esas 5
  páginas por su slug, así que funcionan desde el primer momento aunque
  no configures ningún menú de WordPress a mano.

Qué puedes cambiar desde el escritorio de WordPress
-----------------------------------------------------
- El TEXTO de cada sección vive directamente en el código de su
  plantilla (template-que-es.php, template-que-hacemos.php, etc.), no en
  el editor de la página — así que para cambiar textos, imágenes de
  proyectos/partners o el vídeo de portada, hay que editar el archivo
  correspondiente dentro de /wp-content/themes/concertsost/ (o pedirle a
  quien mantenga la web que lo haga). El campo "contenido" de cada
  página en el editor de WordPress no se usa y puede quedar vacío.
- Si creas un menú personalizado en Apariencia > Menús, el tema seguirá
  usando los enlaces fijos del nav (no lee ese menú); es una mejora
  pendiente si más adelante quieres gestionar el menú desde el admin.

Estructura del tema
--------------------
style.css                  Hoja de estilos completa (con la cabecera de
                            tema que exige WordPress) + toda la
                            identidad visual de Concertsost.
functions.php               Registro de scripts/estilos, alta automática
                            de las 5 páginas, helper de enlaces.
header.php / footer.php     Cabecera y pie comunes a todas las páginas.
front-page.php              Portada (vídeo + hero).
template-que-es.php         Página "Qué es".
template-que-hacemos.php    Página "Qué hacemos".
template-proyectos.php      Página "Proyectos".
template-ecosistema.php     Página "Ecosistema" (logos de partners).
template-contacto.php       Página "Contacto".
page.php / index.php        Plantillas de respaldo genéricas.
assets/img/                 Fotografías, logo y logos de partners.
assets/video/                Vídeo de portada (hero-video.mp4) y su
                            imagen de vista previa (hero-poster.jpg).
assets/js/main.js           Menú móvil, animaciones de aparición al
                            hacer scroll, efecto tilt y la animación 3D
                            de nodos del hero.

Contenido pendiente / a revisar
---------------------------------
- El vídeo de portada está comprimido a ~12,7 MB (720p, sin audio) para
  que cargue rápido. Si en algún momento quieres más calidad, sustituye
  assets/video/hero-video.mp4 por una versión nueva con el mismo nombre.
- El logo (assets/img/logo.png) es la versión en color de baja
  resolución ya usada en la web; si se genera un SVG definitivo,
  sustituir este archivo y actualizar las referencias en header.php y
  footer.php si cambia el nombre.
