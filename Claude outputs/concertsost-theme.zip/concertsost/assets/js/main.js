(function(){

    var toggle = document.getElementById('navToggle');
    var links = document.getElementById('navLinks');
    toggle.addEventListener('click', function(){
      var open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    links.querySelectorAll('a').forEach(function(a){
      a.addEventListener('click', function(){
        links.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });

    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    var heroVideo = document.querySelector('#video-hero video');
    if(heroVideo && reduceMotion){
      heroVideo.removeAttribute('autoplay');
      heroVideo.pause();
    }

    // scroll reveal
    if(!reduceMotion && 'IntersectionObserver' in window){
      var io = new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
          if(entry.isIntersecting){
            entry.target.classList.add('in');
            io.unobserve(entry.target);
          }
        });
      }, {threshold:.15});
      document.querySelectorAll('.reveal').forEach(function(el){ io.observe(el); });
    } else {
      document.querySelectorAll('.reveal').forEach(function(el){ el.classList.add('in'); });
    }

    // tilt effect on cards/images
    if(!reduceMotion){
      document.querySelectorAll('[data-tilt]').forEach(function(card){
        card.addEventListener('pointermove', function(e){
          var rect = card.getBoundingClientRect();
          var px = (e.clientX - rect.left) / rect.width - 0.5;
          var py = (e.clientY - rect.top) / rect.height - 0.5;
          card.style.transform = 'perspective(700px) rotateX(' + (-py*7) + 'deg) rotateY(' + (px*7) + 'deg) translateY(-3px)';
        });
        card.addEventListener('pointerleave', function(){ card.style.transform = ''; });
      });
    }

    // ---- 3D node canvas ----
    var canvas = document.getElementById('nodeCanvas');
    if(canvas){
      var ctx = canvas.getContext('2d');
      var W, H, DPR;
      function resize(){
        DPR = Math.min(window.devicePixelRatio || 1, 2);
        var rect = canvas.getBoundingClientRect();
        W = rect.width; H = rect.height;
        canvas.width = W * DPR; canvas.height = H * DPR;
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      }
      window.addEventListener('resize', resize);

      var N = 32;
      var nodes = [];
      for(var i=0; i<N; i++){
        var theta = Math.random() * Math.PI * 2;
        var phi = Math.acos(2*Math.random() - 1);
        var r = 118 + Math.random()*42;
        nodes.push({
          x: r * Math.sin(phi) * Math.cos(theta),
          y: r * Math.sin(phi) * Math.sin(theta),
          z: r * Math.cos(phi)
        });
      }

      var rotY = 0, rotX = 0.32, targetRotX = 0.32;

      function project(p, focal){
        var cosY = Math.cos(rotY), sinY = Math.sin(rotY);
        var x = p.x*cosY - p.z*sinY;
        var z = p.x*sinY + p.z*cosY;
        var cosX = Math.cos(rotX), sinX = Math.sin(rotX);
        var y = p.y*cosX - z*sinX;
        z = p.y*sinX + z*cosX;
        var scale = focal / (focal + z);
        return {x: x*scale, y: y*scale, z: z, scale: scale};
      }

      function draw(){
        ctx.clearRect(0, 0, W, H);
        var cx = W/2, cy = H/2, focal = 320;
        var projected = nodes.map(function(p){ return project(p, focal); });
        for(var i=0; i<N; i++){
          for(var j=i+1; j<N; j++){
            var dx = nodes[i].x-nodes[j].x, dy = nodes[i].y-nodes[j].y, dz = nodes[i].z-nodes[j].z;
            var d = Math.sqrt(dx*dx+dy*dy+dz*dz);
            if(d < 92){
              var a = projected[i], b = projected[j];
              var op = Math.max(0, (1 - d/92)) * 0.32 * ((a.scale+b.scale)/2);
              ctx.strokeStyle = 'rgba(64,183,42,' + op + ')';
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.moveTo(cx+a.x, cy+a.y);
              ctx.lineTo(cx+b.x, cy+b.y);
              ctx.stroke();
            }
          }
        }
        var order = projected.map(function(p,i){ return i; }).sort(function(a,b){ return projected[a].z - projected[b].z; });
        order.forEach(function(i){
          var p = projected[i];
          var rr = Math.max(1.6, 3.8*p.scale);
          var isAccent = i % 7 === 0;
          ctx.fillStyle = isAccent ? 'rgba(0,0,0,' + (0.5*p.scale+0.2) + ')' : 'rgba(64,183,42,' + (0.55*p.scale+0.25) + ')';
          ctx.beginPath();
          ctx.arc(cx+p.x, cy+p.y, rr, 0, Math.PI*2);
          ctx.fill();
        });
      }

      resize();
      if(reduceMotion){
        draw();
      } else {
        (function loop(){
          rotY += 0.0022;
          rotX += (targetRotX - rotX) * 0.02;
          draw();
          requestAnimationFrame(loop);
        })();
        window.addEventListener('mousemove', function(e){
          var rect = canvas.getBoundingClientRect();
          if(e.clientY < rect.top || e.clientY > rect.bottom) return;
          var relY = (e.clientY - rect.top - rect.height/2) / rect.height;
          targetRotX = 0.32 + relY*0.4;
        });
      }
    }
  })();
