<?php
/**
 * Plantilla de respaldo obligatoria de WordPress. front-page.php cubre la
 * portada y cada sección tiene su propia plantilla, así que este archivo
 * solo entra en juego en casos no contemplados (por ejemplo, el listado
 * de entradas del blog, si en algún momento se usa).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>

<section id="contenido-generico">
  <div class="wrap" style="padding:var(--space-7) 0;">
    <?php if ( have_posts() ) : ?>
      <?php
      while ( have_posts() ) :
        the_post();
        ?>
        <article <?php post_class( 'reveal' ); ?> style="margin-bottom:var(--space-6);">
          <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <div class="entry-summary" style="max-width:70ch;">
            <?php the_excerpt(); ?>
          </div>
        </article>
        <?php
      endwhile;
      ?>
    <?php else : ?>
      <p><?php esc_html_e( 'No se ha encontrado contenido.', 'concertsost' ); ?></p>
    <?php endif; ?>
  </div>
</section>

<?php get_footer(); ?>
