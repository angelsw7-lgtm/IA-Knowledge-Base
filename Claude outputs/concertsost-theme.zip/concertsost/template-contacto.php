<?php
/**
 * Template Name: Contacto
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>

<section id="contacto">
  <div class="seam seam-to-contacto"></div>
  <div class="blob contact-glow" aria-hidden="true"></div>
  <div class="wrap contact-inner">
    <div class="reveal">
      <p class="eyebrow on-dark">05 · Contacto</p>
      <h2>¿Hablamos de tu próxima alianza?</h2>
      <p class="lede">Empresas, marcas, instituciones y profesionales del ecosistema de eventos — cuéntanos tu proyecto.</p>
    </div>
    <div class="contact-actions reveal d1">
      <a class="btn btn-onDark" href="mailto:info@concertsost.com">info@concertsost.com</a>
      <a class="btn btn-onDark-outline" href="mailto:comunicacion@concertsost.com">comunicacion@concertsost.com</a>
      <span class="contact-note">Información general · Comunicación y prensa</span>
    </div>
  </div>
  <div class="seam-bottom seam-to-footer"></div>
</section>

<?php get_footer(); ?>
