<?php
/**
 * Template Name: Ecosistema
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>

<section id="ecosistema">
  <div class="wrap">
    <div class="section-head on-dark reveal">
      <p class="eyebrow on-dark">04 · Ecosistema</p>
      <h2 style="color:#fff;">Empresas, instituciones y profesionales</h2>
      <p>Marcas, instituciones y partners que forman parte del ecosistema Concertsost.</p>
    </div>
    <div class="partner-row reveal">
      <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-ayto-castello.png' ); ?>" alt="Ayuntamiento de Castellón" loading="lazy"></div>
      <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-babalu.png' ); ?>" alt="Babalú" loading="lazy"></div>
      <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-logo2.png' ); ?>" alt="Partner Concertsost" loading="lazy"></div>
      <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-bcdme.png' ); ?>" alt="BCDME" loading="lazy"></div>
      <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-skyfest.png' ); ?>" alt="SkyFest" loading="lazy"></div>
      <div class="partner-slot"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/partner-patos.png' ); ?>" alt="Producciones Artísticas Patos" loading="lazy"></div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
