<?php
/**
 * Pie del sitio.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</main>

<footer class="site-foot">
  <div class="wrap foot-grid">
    <a class="foot-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Concertsost">
      <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo.png' ); ?>" alt="Concertsost">
    </a>
    <nav class="foot-links">
      <a href="<?php echo esc_url( concertsost_page_link( 'que-es' ) ); ?>">Qué es</a>
      <a href="<?php echo esc_url( concertsost_page_link( 'que-hacemos' ) ); ?>">Qué hacemos</a>
      <a href="<?php echo esc_url( concertsost_page_link( 'proyectos' ) ); ?>">Proyectos</a>
      <a href="<?php echo esc_url( concertsost_page_link( 'ecosistema' ) ); ?>">Ecosistema</a>
      <a href="<?php echo esc_url( concertsost_page_link( 'contacto' ) ); ?>">Contacto</a>
      <a href="https://www.instagram.com/concert.sost?stkn=MW1lcHczZ3lxNTBtdw==" target="_blank" rel="noopener">Instagram</a>
    </nav>
    <span class="foot-meta">© <?php echo esc_html( date( 'Y' ) ); ?> CONCERTSOST</span>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
