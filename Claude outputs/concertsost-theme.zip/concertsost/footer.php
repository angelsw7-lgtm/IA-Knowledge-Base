<?php
/**
 * Pie del sitio. Enlaces por ancla, igual que la cabecera.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</main>

<footer class="site-foot">
  <div class="wrap foot-grid">
    <a class="foot-logo" href="#top" aria-label="Concertsost">
      <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo.png' ); ?>" alt="Concertsost">
    </a>
    <nav class="foot-links">
      <a href="#que-es">Qué es</a>
      <a href="#que-hacemos">Qué hacemos</a>
      <a href="#proyectos">Proyectos</a>
      <a href="#ecosistema">Ecosistema</a>
      <a href="#contacto">Contacto</a>
    </nav>
    <span class="foot-meta">© <?php echo esc_html( date( 'Y' ) ); ?> CONCERTSOST</span>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
