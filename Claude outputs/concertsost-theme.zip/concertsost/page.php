<?php
/**
 * Plantilla genérica de página (fallback), para cualquier página que no
 * use una de las plantillas de sección dedicadas.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>

<section id="pagina-generica">
  <div class="wrap" style="padding:var(--space-7) 0;">
    <?php
    while ( have_posts() ) :
      the_post();
      ?>
      <h1 class="reveal"><?php the_title(); ?></h1>
      <div class="entry-content reveal d1" style="max-width:70ch; margin-top:var(--space-3);">
        <?php the_content(); ?>
      </div>
      <?php
    endwhile;
    ?>
  </div>
</section>

<?php get_footer(); ?>
