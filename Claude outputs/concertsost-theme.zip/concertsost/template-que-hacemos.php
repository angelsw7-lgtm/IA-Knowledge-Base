<?php
/**
 * Template Name: Qué hacemos
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>

<section id="que-hacemos">
  <div class="seam seam-to-hacemos"></div>
  <div class="wrap">
    <div class="section-head reveal">
      <p class="eyebrow">02 · Qué hacemos</p>
      <h2>Nueve territorios, un mismo punto de conexión</h2>
      <p>Las áreas en las que Concertsost genera oportunidades dentro del ecosistema de eventos.</p>
    </div>
    <div class="areas-grid">
      <div class="area-card reveal tilt" data-tilt><span class="node-dot"></span><h3>Alianzas</h3><p>Conectamos empresas e instituciones para construir colaboraciones con propósito.</p></div>
      <div class="area-card reveal d1 tilt" data-tilt><span class="node-dot"></span><h3>Nuevos proyectos</h3><p>Impulsamos iniciativas que nacen del cruce entre distintos sectores del ecosistema.</p></div>
      <div class="area-card reveal d2 tilt" data-tilt><span class="node-dot"></span><h3>Patrocinios</h3><p>Acercamos marcas y eventos que comparten valores y objetivos.</p></div>
      <div class="area-card reveal d3 tilt" data-tilt><span class="node-dot"></span><h3>Turismo + música</h3><p>Unimos el atractivo cultural de la música con el desarrollo del turismo profesional.</p></div>
      <div class="area-card reveal tilt" data-tilt><span class="node-dot"></span><h3>Innovación</h3><p>Exploramos nuevos formatos y tecnologías aplicadas a la experiencia de eventos.</p></div>
      <div class="area-card reveal d1 tilt" data-tilt><span class="node-dot"></span><h3>Sostenibilidad</h3><p>Integramos criterios sostenibles en cada alianza y proyecto.</p></div>
      <div class="area-card reveal d2 tilt" data-tilt><span class="node-dot"></span><h3>Networking</h3><p>Creamos espacios de encuentro entre profesionales del sector.</p></div>
      <div class="area-card reveal d3 tilt" data-tilt><span class="node-dot"></span><h3>Nuevos formatos</h3><p>Diseñamos maneras distintas de vivir y organizar encuentros profesionales.</p></div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
