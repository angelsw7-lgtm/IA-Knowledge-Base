<?php
/**
 * Concertsost theme functions.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CONCERTSOST_VERSION', '1.0.0' );

/**
 * Theme setup.
 */
function concertsost_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);

	register_nav_menus(
		array(
			'primary' => __( 'Menú principal', 'concertsost' ),
		)
	);
}
add_action( 'after_setup_theme', 'concertsost_setup' );

/**
 * Styles and scripts.
 */
function concertsost_scripts() {
	wp_enqueue_style(
		'concertsost-fonts',
		'https://fonts.googleapis.com/css2?family=Manrope:wght@500;600;700;800&family=Karla:ital,wght@0,400;0,500;0,600;1,400&family=IBM+Plex+Mono:wght@400;500&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'concertsost-style', get_stylesheet_uri(), array(), CONCERTSOST_VERSION );
	wp_enqueue_script( 'concertsost-main', get_template_directory_uri() . '/assets/js/main.js', array(), CONCERTSOST_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'concertsost_scripts' );

/**
 * Devuelve la URL de una página del sitio a partir de su slug.
 *
 * Si la página todavía no existe (por ejemplo, justo tras instalar el tema
 * antes de que se ejecute el alta automática) devuelve una URL de
 * fallback con el mismo slug para que el enlace no quede roto.
 *
 * @param string $slug Slug de la página (que-es, que-hacemos, proyectos, ecosistema, contacto).
 * @return string URL absoluta de la página.
 */
function concertsost_page_link( $slug ) {
	$page = get_page_by_path( $slug );
	if ( $page ) {
		return get_permalink( $page );
	}
	return home_url( '/' . $slug . '/' );
}

/**
 * Crea automáticamente, al activar el tema, las páginas de cada sección
 * con la plantilla correspondiente ya asignada. Así el sitio funciona
 * de inmediato, sin tener que crear las páginas a mano desde el admin.
 */
function concertsost_create_default_pages() {
	$pages = array(
		'que-es'      => array(
			'title'    => 'Qué es',
			'template' => 'template-que-es.php',
		),
		'que-hacemos' => array(
			'title'    => 'Qué hacemos',
			'template' => 'template-que-hacemos.php',
		),
		'proyectos'   => array(
			'title'    => 'Proyectos',
			'template' => 'template-proyectos.php',
		),
		'ecosistema'  => array(
			'title'    => 'Ecosistema',
			'template' => 'template-ecosistema.php',
		),
		'contacto'    => array(
			'title'    => 'Contacto',
			'template' => 'template-contacto.php',
		),
	);

	foreach ( $pages as $slug => $data ) {
		$existing = get_page_by_path( $slug );
		if ( $existing ) {
			continue;
		}

		$page_id = wp_insert_post(
			array(
				'post_title'   => $data['title'],
				'post_name'    => $slug,
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '',
			)
		);

		if ( $page_id && ! is_wp_error( $page_id ) ) {
			update_post_meta( $page_id, '_wp_page_template', $data['template'] );
		}
	}

	// Si el sitio no tiene ya una portada estática configurada, no hace
	// falta hacer nada más: front-page.php se usa automáticamente como
	// portada en cuanto existe en el tema, sin tocar Ajustes > Lectura.
}
add_action( 'after_switch_theme', 'concertsost_create_default_pages' );
