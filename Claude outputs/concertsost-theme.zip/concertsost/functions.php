<?php
/**
 * Concertsost theme functions.
 *
 * Tema de una sola página: no hay páginas de WordPress que crear ni
 * enlaces dinámicos que resolver — el menú apunta a anclas (#que-es,
 * #que-hacemos, etc.) dentro de la propia portada, igual que el
 * artefacto original.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CONCERTSOST_VERSION', '2.0.0' );

/**
 * Theme setup.
 */
function concertsost_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);
}
add_action( 'after_setup_theme', 'concertsost_setup' );

/**
 * Styles and scripts.
 */
function concertsost_scripts() {
	wp_enqueue_style(
		'concertsost-fonts',
		'https://fonts.googleapis.com/css2?family=Manrope:wght@500;600;700;800&family=Karla:ital,wght@0,400;0,500;0,600;1,400&family=IBM+Plex+Mono:wght@400;500&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'concertsost-style', get_stylesheet_uri(), array(), CONCERTSOST_VERSION );
	wp_enqueue_script( 'concertsost-main', get_template_directory_uri() . '/assets/js/main.js', array(), CONCERTSOST_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'concertsost_scripts' );
