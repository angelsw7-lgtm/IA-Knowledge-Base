<?php
/**
 * Template Name: Proyectos
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>

<section id="proyectos">
  <div class="seam seam-to-proyectos"></div>
  <div class="wrap">
    <div class="section-head on-dark reveal">
      <p class="eyebrow on-dark">03 · Proyectos y oportunidades</p>
      <h2 style="color:#fff;">Proyectos del ecosistema</h2>
      <p>Una muestra de alianzas y producciones en las que Concertsost ha estado detrás del escenario.</p>
    </div>
    <div class="proj-grid">
      <div class="proj-card reveal">
        <div class="proj-img" style="background-image:url('<?php echo esc_url( get_template_directory_uri() . '/assets/img/proyecto-skyfest-benidorm.jpg' ); ?>')" role="img" aria-label="SkyFest Benidorm"></div>
        <div class="proj-body">
          <span class="proj-tag">Proyecto realizado</span>
          <h3>SkyFest Benidorm</h3>
          <p>Gestión y asesoramiento del festival.</p>
        </div>
      </div>
      <div class="proj-card reveal d1">
        <div class="proj-img" style="background-image:url('<?php echo esc_url( get_template_directory_uri() . '/assets/img/proyecto-hombresg-castellon.jpg' ); ?>')" role="img" aria-label="Hombres G en Castellón"></div>
        <div class="proj-body">
          <span class="proj-tag">Proyecto realizado</span>
          <h3>Hombres G en Castellón</h3>
          <p>Producción y gestión íntegra del concierto.</p>
        </div>
      </div>
      <div class="proj-card reveal d2">
        <div class="proj-img" style="background-image:url('<?php echo esc_url( get_template_directory_uri() . '/assets/img/proyecto-vinalfest.jpg' ); ?>')" role="img" aria-label="Vinal Fest"></div>
        <div class="proj-body">
          <span class="proj-tag">Proyecto realizado</span>
          <h3>Vinal Fest</h3>
          <p>Producción y gestión íntegra del festival.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
