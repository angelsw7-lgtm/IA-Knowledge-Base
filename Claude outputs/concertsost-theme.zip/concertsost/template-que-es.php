<?php
/**
 * Template Name: Qué es
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
?>

<section id="que-es">
  <div class="seam seam-to-que-es"></div>
  <div class="wrap que-es-grid">
    <div class="reveal">
      <p class="eyebrow">01 · Qué es Concertsost</p>
      <p><strong>Concertsost es una marca B2B del ecosistema de eventos.</strong> No somos una productora musical, ni una consultora tradicional, ni una plataforma de ticketing — somos el punto donde empresas, marcas, instituciones y profesionales se conectan para construir algo nuevo alrededor de los eventos.</p>
      <p>Trabajamos en el cruce entre negocio, cultura y oportunidad: alianzas, patrocinios, turismo y música, innovación y sostenibilidad aplicada al mundo de los encuentros profesionales.</p>
    </div>
    <div class="reveal d1">
      <div class="photo-frame tilt" data-tilt>
        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/que-es-referencia.jpg' ); ?>" alt="Concierto de Hombres G — producción Concertsost" loading="lazy">
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
