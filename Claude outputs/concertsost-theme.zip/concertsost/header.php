<?php
/**
 * Cabecera del sitio: doctype, <head> y nav.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Concertsost conecta empresas, marcas, instituciones y profesionales para generar alianzas, patrocinios y nuevos proyectos en el ecosistema de eventos.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-nav">
  <div class="wrap nav-inner">
    <a class="nav-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Concertsost — inicio">
      <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/logo.png' ); ?>" alt="Concertsost">
    </a>
    <nav class="nav-links" id="navLinks">
      <a href="<?php echo esc_url( concertsost_page_link( 'que-es' ) ); ?>">Qué es</a>
      <a href="<?php echo esc_url( concertsost_page_link( 'que-hacemos' ) ); ?>">Qué hacemos</a>
      <a href="<?php echo esc_url( concertsost_page_link( 'proyectos' ) ); ?>">Proyectos</a>
      <a href="<?php echo esc_url( concertsost_page_link( 'ecosistema' ) ); ?>">Ecosistema</a>
      <a class="nav-social" href="https://www.instagram.com/concert.sost?stkn=MW1lcHczZ3lxNTBtdw==" target="_blank" rel="noopener" aria-label="Concertsost en Instagram">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <rect x="3" y="3" width="18" height="18" rx="5.5"></rect>
          <circle cx="12" cy="12" r="4.2"></circle>
          <circle cx="17.15" cy="6.85" r="1.05" fill="currentColor" stroke="none"></circle>
        </svg>
      </a>
      <a href="<?php echo esc_url( concertsost_page_link( 'contacto' ) ); ?>" class="nav-cta">Hablemos</a>
    </nav>
    <button class="nav-toggle" id="navToggle" aria-label="Abrir menú" aria-expanded="false" aria-controls="navLinks">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>

<main id="top">
